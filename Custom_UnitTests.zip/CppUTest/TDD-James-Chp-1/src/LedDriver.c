/*
 * LedDriver.c
 *
 *  Created on: 13 Apr 2022
 *      Author: jsirs
 */


#include "LedDriver.h"

static uint16_t* ledAddress;

void LedDriverCreate(uint16_t * address)
{
	ledAddress = address;
	*ledAddress = 0;
}

void LedDriverTurnOn(int ledNumber)
{
	*ledAddress = 0x1;
}

void LedDriverTurnOff(int ledNumber)
{
	*ledAddress = 0;
}
