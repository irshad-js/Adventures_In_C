/*
 ============================================================================
 Name        : NativeFiles_Unity.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style

 necessary - C:\msys64\mingw64

 ============================================================================
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "LedDriver.h"

#include "unity.h"
#include "unity_fixture.h"

TEST_GROUP(LED_Driver);

static uint16_t virtualLeds;

TEST_SETUP(LED_Driver)
{
	LedDriverCreate(&virtualLeds);
}

TEST_TEAR_DOWN(LED_Driver)
{

}

TEST(LED_Driver,LedOffAfterCreate)
{
	uint16_t virtualLeds = 0xFFFF;
	LedDriverCreate(&virtualLeds);
	TEST_ASSERT_EQUAL_HEX16(0x0,virtualLeds);
}

TEST(LED_Driver,TurnOnLedOne)
{
	LedDriverTurnOn(1);
	TEST_ASSERT_EQUAL_HEX16(0x1,virtualLeds);
}

TEST(LED_Driver,TurnOffLedOne)
{
	LedDriverTurnOn(1);
	LedDriverTurnOff(1);
	TEST_ASSERT_EQUAL_HEX16(0x0,virtualLeds);
}

TEST_GROUP_RUNNER(LED_Driver)
{
    RUN_TEST_CASE(LED_Driver,LedOffAfterCreate);
    RUN_TEST_CASE(LED_Driver,TurnOnLedOne);
    RUN_TEST_CASE(LED_Driver,TurnOffLedOne);
}



int main(void)
{
	UNITY_BEGIN();
    RUN_TEST_GROUP(LED_Driver);
    return UNITY_END();
}
