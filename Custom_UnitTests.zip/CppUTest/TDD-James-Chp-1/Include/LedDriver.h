#ifndef LED_H
#define LED_H

#include <stdint.h>

void LedDriverCreate(uint16_t * address);
void LedDriverTurnOn(int ledNumber);
void LedDriverTurnOff(int ledNumber);
#endif
