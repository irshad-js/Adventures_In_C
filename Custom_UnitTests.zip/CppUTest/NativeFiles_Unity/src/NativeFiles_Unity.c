/*
 ============================================================================
 Name        : NativeFiles_Unity.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include "unity.h"
#include "unity_fixture.h"

static void First_Test(void){

    TEST_ASSERT_EQUAL_INT8_MESSAGE(2,2,"Test-1 OK PASS");

}

#define Test_print

TEST_GROUP(Test_Setup);

TEST_SETUP(Test_Setup){

#ifdef Test_print
    printf("\nTest setup is Initialized - From Test runner\n");
#endif

}

TEST_TEAR_DOWN(Test_Setup){

#ifdef Test_print
    printf("\nTest setup is De-Initialized - From Test runner\n");
#endif

}

TEST(Test_Setup,First_Test_Run){

	First_Test();

}

TEST_GROUP_RUNNER(Test_Setup){

    RUN_TEST_CASE(Test_Setup,First_Test_Run);

}



int main(void) {

	puts("!!!Hello World!!!\n"); /* prints !!!Hello World!!! */

	//return EXIT_SUCCESS;

	UNITY_BEGIN();

    RUN_TEST_GROUP(Test_Setup);

    return UNITY_END();
}
