/*
 * testRunner.cpp
 *
 *  Created on: Dec 9, 2012
 *      Author: pf
 */


#include <CppUTest/TestHarness.h>

extern "C" {

}

TEST_GROUP(DummyGroup)
{
	void setup()
	{

	}

	void teardown()
	{

	}
};


TEST(DummyGroup, OnlyTest)
{
	FAIL("Fail me once and twice!");
}
