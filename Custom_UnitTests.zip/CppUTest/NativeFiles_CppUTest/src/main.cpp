//============================================================================
// Name        : main.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <CppUTest/CommandLineTestRunner.h>

int main(int argc, char **argv)
{
	return  CommandLineTestRunner::RunAllTests(argc,argv);
}

