#ifdef TEST

#include "unity.h"

#include "bit_manipulation.h"
#include "adc.h"
#include "mock_adc.h"

extern uint8_t Julie;
extern uint8_t Pete;
extern uint8_t Donkey;

void setUp(void)
{
	Julie = 0x00;
	Pete = 0xFF;
	Donkey =0x00;
}

void tearDown(void)
{
}

void test_bit_manipulation_NeedToImplement(void)
{
	int8_t result;
	result = do_bit_man( 15 );

	TEST_ASSERT_EQUAL_INT8( -1, result );
	TEST_ASSERT_EQUAL_INT8( 0x00, Julie );
	TEST_ASSERT_EQUAL_INT8( 0xFF, Pete );
	TEST_ASSERT_EQUAL_INT8( 0x00, Donkey );
}

void test_bit_manipulation_NeedToImplement_2(void)
{
	int8_t result;
	result = do_bit_man( -5 );

	TEST_ASSERT_EQUAL_INT8( -1, result );
	TEST_ASSERT_EQUAL_INT8( 0x00, Julie );
	TEST_ASSERT_EQUAL_INT8( 0xFF, Pete );
	TEST_ASSERT_EQUAL_INT8( 0x00, Donkey );
}
//Test Case 2 
void test_do_bit_man_2(void) 
{
  int8_t result;
  int8_t position = 5;
      //This will return 35, which prints Temperature is High
  adc_read_ExpectAndReturn(10);
    
  result = do_bit_man( position );
  TEST_ASSERT_EQUAL_INT8( 0, result );

}

void test_do_bit_man_3(void) 
{
  int8_t result;
  int8_t position = 5;
      //This will return 35, which prints Temperature is High
  adc_read_ExpectAndReturn(40);
    
  result = do_bit_man( position );
  TEST_ASSERT_EQUAL_INT8( 0, result );

}

#endif // TEST
