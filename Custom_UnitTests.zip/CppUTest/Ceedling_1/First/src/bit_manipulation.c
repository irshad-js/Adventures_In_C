#include "bit_manipulation.h"
#include "adc.h"

uint8_t Julie= 0x00;
uint8_t Pete= 0xFF;
uint8_t Donkey= 0x00;

int8_t do_bit_man(int8_t position)
{
    if( ( position < 0 ) || ( position > 7 ) ) 
    {
        //position should be 0 to 7. Because we are going to modify 8 bit value.
        return -1;
    }
    
	Julie|= ( 1 << position );
	
	Pete&= ~( 1 << position );

	Donkey^= ( 1 << position );
	
	    int result = adc_read();
    
    if( result >= 30 )
    {
        printf("Temperature is High\n");
    }
    else
    {
        printf("Temperature is Low\n");
    }
    
    return 0;

    return 0;
}