/* This source is just for understanding purpose.
** There is no logic here. We are not going to use
** this code. This will be used for understand the
** Unit test.
*/

#ifndef ADC_H
#define ADC_H

/* Read ADC value */
int adc_read( void );

#endif // ADC_H