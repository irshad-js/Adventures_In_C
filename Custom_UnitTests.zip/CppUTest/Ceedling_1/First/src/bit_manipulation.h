#ifndef BIT_MANIPULATION_H
#define BIT_MANIPULATION_H

#include <stdio.h>
#include <stdint.h>
int8_t do_bit_man(int8_t position);

#endif // BIT_MANIPULATION_H
