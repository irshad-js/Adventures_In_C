/*
 ============================================================================
 Name        : NativeFiles_Unity.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style

 necessary - C:\msys64\mingw64

 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

#include "unity.h"
#include "unity_fixture.h"

TEST_GROUP(LED_Driver);

TEST_SETUP(LED_Driver){

}

TEST_TEAR_DOWN(LED_Driver){

}

TEST(LED_Driver,First_Test_Run){



}

TEST_GROUP_RUNNER(LED_Driver){

    RUN_TEST_CASE(LED_Driver,First_Test_Run);

}



int main(void) {

	puts("!!!Hello World!!!\n"); /* prints !!!Hello World!!! */

	//return EXIT_SUCCESS;

	UNITY_BEGIN();

    RUN_TEST_GROUP(LED_Driver);

    return UNITY_END();
}
