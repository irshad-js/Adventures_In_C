#ifndef LED_H
#define LED_H

#include <stdint.h>
#include <stdbool.h>

void LedDriverCreate(uint16_t * address);
void LedDriverTurnOn(int ledNumber);
void LedDriverTurnOff(int ledNumber);
void LedDriverTurnOnAll(void);
bool LedDriverIsOn(int ledNumber);
bool LedDriverIsOff(int ledNumber);
void LedDriverTurnOffAll(void);

#endif
