/*
 * LedDriver.c
 *
 *  Created on: 13 Apr 2022
 *      Author: jsirs
 */


#include "LedDriver.h"
#include "Error.h"


static uint16_t* ledAddress;
static uint16_t ledImage;

enum{All_Leds_Off =0x0, All_Leds_On = 0xFFFF};
enum{MinimumLed = 0x1,MaximumLed = 16};

static uint16_t OffsetLedNumber(int ledNumber)
{
	return 1 << (ledNumber-1);
}

static uint16_t IsLedWithinLimits(int ledNumber)
{
	return (ledNumber <= MaximumLed && ledNumber >= MinimumLed);
}

static void UpdateHardware(void)
{
	*ledAddress = ledImage;
}

static void SetLedBits(int ledNumber)
{
	ledImage |= OffsetLedNumber(ledNumber);
}

static void ClearLedBits(int ledNumber)
{
	ledImage &= ~(OffsetLedNumber(ledNumber));
}

void LedDriverCreate(uint16_t * address)
{
	ledAddress = address;
	ledImage = All_Leds_Off;
	UpdateHardware();
}

void LedDriverTurnOn(int ledNumber)
{
	if (IsLedWithinLimits(ledNumber))
	{
		SetLedBits(ledNumber);
		UpdateHardware();
	}
}

void LedDriverTurnOff(int ledNumber)
{
	if (IsLedWithinLimits(ledNumber))
	{
		ClearLedBits(ledNumber);
		UpdateHardware();
	}
}

void LedDriverTurnOnAll(void)
{
	ledImage = All_Leds_On;
	UpdateHardware();
}

void LedDriverTurnOffAll(void)
{
	ledImage = All_Leds_Off;
	UpdateHardware();
}

bool LedDriverIsOn(int ledNumber)
{
	if (IsLedWithinLimits(ledNumber))
	{
		return ledImage & OffsetLedNumber(ledNumber);
	}

	return 0;
}

bool LedDriverIsOff(int ledNumber)
{
	if (IsLedWithinLimits(ledNumber))
	{
		return !(ledImage & OffsetLedNumber(ledNumber));
	}

	return 1;
}
