/*
 ============================================================================
 Name        : NativeFiles_Unity.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style

 necessary - C:\msys64\mingw64

 ============================================================================
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#include "Error.h"
#include "LedDriver.h"

#include "unity.h"
#include "unity_fixture.h"

TEST_GROUP(LED_Driver);

static uint16_t virtualLeds;

TEST_SETUP(LED_Driver)
{
	LedDriverCreate(&virtualLeds);
}

TEST_TEAR_DOWN(LED_Driver)
{

}

TEST(LED_Driver,LedOffAfterCreate)
{
	uint16_t virtualLeds = 0xFFFF;
	LedDriverCreate(&virtualLeds);
	TEST_ASSERT_EQUAL_HEX16(0x0,virtualLeds);
}

TEST(LED_Driver,TurnOnLedOne)
{
	LedDriverTurnOn(1);
	TEST_ASSERT_EQUAL_HEX16(0x1,virtualLeds);
}

TEST(LED_Driver,TurnOffLedOne)
{
	LedDriverTurnOn(1);
	LedDriverTurnOff(1);
	TEST_ASSERT_EQUAL_HEX16(0x0,virtualLeds);
}

TEST(LED_Driver,TurnOnMultipleLeds)
{
	LedDriverTurnOn(8);
	LedDriverTurnOn(9);
	TEST_ASSERT_EQUAL_HEX16((1<<7)|(1<<8),virtualLeds);
}

TEST(LED_Driver,TurnOffAnyLed)
{
	LedDriverTurnOnAll();
	LedDriverTurnOff(8);
	TEST_ASSERT_EQUAL_HEX16(0xFFFF&~(1<<7),virtualLeds);
}

TEST(LED_Driver,TurnOnAllLeds)
{
	LedDriverTurnOnAll();
	TEST_ASSERT_EQUAL_HEX16(0xFFFF,virtualLeds);
}

TEST(LED_Driver,LedMemoryReadable)
{
	virtualLeds = 0xFFFF;
	LedDriverTurnOn(8);
	TEST_ASSERT_EQUAL_HEX16((1<<7),virtualLeds);
}

TEST(LED_Driver,UpperAndLowerBounds)
{
	LedDriverTurnOn(1);
	LedDriverTurnOn(16);
	TEST_ASSERT_EQUAL_HEX16((1<<0)|(1<<15),virtualLeds);
}

TEST(LED_Driver,OutOfBoundsChangesNothing)
{
	LedDriverTurnOn(-1);
	LedDriverTurnOn(0);
	LedDriverTurnOn(17);
	LedDriverTurnOn(3141);
	TEST_ASSERT_EQUAL_HEX16(0,virtualLeds);
}

TEST(LED_Driver,OutOfBoundsTurnOffDoesNoHarm)
{
	LedDriverTurnOnAll();
	LedDriverTurnOff(-1);
	LedDriverTurnOff(0);
	LedDriverTurnOff(17);
	LedDriverTurnOff(3141);
	TEST_ASSERT_EQUAL_HEX16(0xFFFF,virtualLeds);
}

TEST(LED_Driver, OutOfBoundsProducesRuntimeError)
{
	LedDriverTurnOn(-1);
	//TEST_ASSERT_EQUAL_STRING("LED Driver: out-of-bounds LED",RuntimeError(RuntimeErrorStub_GetLastError()));
    TEST_ASSERT_EQUAL(-1, RuntimeErrorStub_GetLastParameter());
}

IGNORE_TEST(LED_Driver, OutOfBoundsToDo)
{

}

TEST(LED_Driver, IsLedOn)
{
	TEST_ASSERT_FALSE(LedDriverIsOn(7));
	LedDriverTurnOn(7);
	TEST_ASSERT_TRUE(LedDriverIsOn(7));
}

TEST(LED_Driver, IsLedOff)
{
	TEST_ASSERT_TRUE(LedDriverIsOff(7));
	LedDriverTurnOn(7);
	TEST_ASSERT_FALSE(LedDriverIsOff(7));
}

TEST(LED_Driver, OutOfBoundsLedIsOff)
{
	TEST_ASSERT_FALSE(LedDriverIsOn(0));
	TEST_ASSERT_FALSE(LedDriverIsOn(17));
}

TEST(LED_Driver, OutOfBoundsLedIsAlwaysOff)
{
	TEST_ASSERT_TRUE(LedDriverIsOff(0));
	TEST_ASSERT_TRUE(LedDriverIsOff(17));
	TEST_ASSERT_FALSE(LedDriverIsOn(0));
	TEST_ASSERT_FALSE(LedDriverIsOn(17));
}

TEST(LED_Driver, TurnOffMultipleLeds)
{
	LedDriverTurnOnAll();
	LedDriverTurnOff(1);
	LedDriverTurnOff(9);
	TEST_ASSERT_EQUAL_HEX16(0xFFFF & ~((1<<8)|(1<<0)),virtualLeds);
}

TEST(LED_Driver, TurnAllOff)
{
	LedDriverTurnOnAll();
	LedDriverTurnOffAll();
	TEST_ASSERT_EQUAL_HEX16(0,virtualLeds);
}

TEST_GROUP_RUNNER(LED_Driver)
{
    RUN_TEST_CASE(LED_Driver,LedOffAfterCreate);
    RUN_TEST_CASE(LED_Driver,TurnOnLedOne);
    RUN_TEST_CASE(LED_Driver,TurnOffLedOne);
    RUN_TEST_CASE(LED_Driver,TurnOnMultipleLeds);
    RUN_TEST_CASE(LED_Driver,TurnOnAllLeds);
    RUN_TEST_CASE(LED_Driver,TurnOffAnyLed);
    RUN_TEST_CASE(LED_Driver,LedMemoryReadable);
    RUN_TEST_CASE(LED_Driver,UpperAndLowerBounds);
    RUN_TEST_CASE(LED_Driver,OutOfBoundsChangesNothing);
    RUN_TEST_CASE(LED_Driver,OutOfBoundsTurnOffDoesNoHarm);
    RUN_TEST_CASE(LED_Driver,OutOfBoundsProducesRuntimeError);
    RUN_TEST_CASE(LED_Driver,OutOfBoundsToDo);
    RUN_TEST_CASE(LED_Driver,IsLedOn);
    RUN_TEST_CASE(LED_Driver,OutOfBoundsLedIsOff);
    RUN_TEST_CASE(LED_Driver,IsLedOff);
    RUN_TEST_CASE(LED_Driver,OutOfBoundsLedIsAlwaysOff);
    RUN_TEST_CASE(LED_Driver,TurnOffMultipleLeds);
    RUN_TEST_CASE(LED_Driver,TurnAllOff);
}



int main(void)
{
	UNITY_BEGIN();
    RUN_TEST_GROUP(LED_Driver);
    return UNITY_END();
}
